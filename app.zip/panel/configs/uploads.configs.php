<?php
/**
 * By MahmoudAp
 * Github: https://github.com/mahmoud-ap
 */

if (!defined('PATH')) die();

/**
 * Uploads Config
 */
$configs['upload']['dir'] = PATH_ASSETS . DS . 'uploads';
$configs['upload']['temp'] = PATH_TEMP;
$configs['upload']['url'] = $configs['url'] . 'assets/uploads/';

?>
